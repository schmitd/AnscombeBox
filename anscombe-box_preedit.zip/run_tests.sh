#!/bin/sh

cargo test ${@}